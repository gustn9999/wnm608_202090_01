<base href="/aau/wnm608/kim.hyunsoo/">

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="lib/css/gridsystem.css">
<link rel="stylesheet" href="lib/css/styleguide.css">
<link rel="stylesheet" href="css/storetheme.css">

<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
<script src="js/products.js"></script>