 <header class="navbar">
   <div class="container display-flex flex-align-center" style="height:70px;">
      <div class="display-flex">
         <img src="images/logo.png" class="nav_logo"><h1 style="margin-left: 10px;"><a href="index.php">Sunny Cocktail</a></h1></div>
      <div class="flex-stretch"></div>
      
      <!-- nav.nav>ul>li*4>a[href=#article$]>{Link $} -->
      <nav class="nav flex-none">
         <ul class="display-flex">
            <li><a href="product_list.php">Shop</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="product_cart.php">Cart</a></li>
         </ul>
      </nav>
   </div>
</header>