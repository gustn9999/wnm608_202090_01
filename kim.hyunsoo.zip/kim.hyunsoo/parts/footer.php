  <div class="footer">
      <div class="footer-block">
         <div class='footer-block-text footer-block-title'>Contact Us</div>
         <a class='footer-block-text footer-block-link' href="mailto:hyunsoo@help.com">hyunsoo@help.com</a>
         <div class='footer-block-text footer-block-phone'>+1(415)-420-0000</div>
      </div>
   </div>