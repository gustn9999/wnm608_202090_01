<?php


function MYSQLIAuth() {
   return [
      "localhost", // Database host location
      "hyunsoo_wnm608", // Database user name
      "hyunsoo_wnm608", // Database user password
      "hyunsoo_wnm608" // Database database name
   ];
}