<!DOCTYPE html>
<html lang="en">
<head>
   <title>Added Product To Cart</title>

   <?php include "parts/meta.php" ?>
</head>
<body>

   <?php include "parts/navbar.php" ?>

   <div class="container">
      <div class="card soft">
         <h2>Added Product To Cart</h2>

         <a href="product_list.php">Back to shopping</a>
      </div>
   </div>

</body>
</html>