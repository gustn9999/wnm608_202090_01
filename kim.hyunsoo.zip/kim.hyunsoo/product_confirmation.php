<?php

include_once "lib/php/functions.php";


?><!DOCTYPE html>
<html lang="en">
<head>
   <title>Thanks</title>

   <?php include "parts/meta.php" ?>
</head>
<body>


   <div class="container">
      <div class="card soft">
      	<img src="images/Thankyou.png" style="width:100%;">
         <h2>Thanks for Purchasing</h2>

         <a href="product_list.php">Back to shopping</a>
      </div>
   </div>

</body>
<footer>
   <?php include "parts/footer.php"; ?>
</footer>
</html>